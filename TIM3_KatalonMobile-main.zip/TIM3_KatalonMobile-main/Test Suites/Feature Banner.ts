<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Feature Banner</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>5707ddc5-4892-4fde-a97d-e7c63c236ab4</testSuiteGuid>
   <testCaseLink>
      <guid>608903a7-e3af-458e-ae8d-43d077628526</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/stepDefinition/Feature Banner/BANNER001 - Tap and Swipe Image Banner</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>6108d2f0-dcbf-4956-8ae1-1a64b7f373d1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/stepDefinition/Feature Banner/BANNER002 - Login to Tap and Swipe Image Banner</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
