<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Feature Pesanan Saya</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>2565c1d5-853b-459c-a85b-8826739bf427</testSuiteGuid>
   <testCaseLink>
      <guid>63846f7c-a202-431f-9da8-af86a7dc65bd</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/stepDefinition/Feature Pesanan Saya/PESANAN001 - Click Pesanan Saya</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
